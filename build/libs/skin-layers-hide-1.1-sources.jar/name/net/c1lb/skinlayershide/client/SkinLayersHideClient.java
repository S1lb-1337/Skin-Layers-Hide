package name.net.c1lb.skinlayershide.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1664;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class SkinLayersHideClient implements ClientModInitializer
{
    @Override
    public void onInitializeClient()
    {
        final boolean[] SkinLayersHideAll = {false};
        final boolean[] SkinLayersHideTop = {false};
        final boolean[] SkinLayersHideLegs = {false};
        // All
        class_304 skin_key_all = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-all",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.all.category"));
        // All no cape
        class_304 skin_key_all_no_cape = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-all-no-cape",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.all.category"));
        //Hat
        class_304 skin_key_hat = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-hat",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.parts.category"));
        //Body
        class_304 skin_key_jacket = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-jacket",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.parts.category"));
        //Right hand
        class_304 skin_key_right_sleeve = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-right-sleeve",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.parts.category"));
        //Left hand
        class_304 skin_key_left_sleeve = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-left-sleeve",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.parts.category"));
        //Right leg
        class_304 skin_key_right_pains_leg = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-right-pains-leg",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.parts.category"));
        //Left leg
        class_304 skin_key_left_pains_leg = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-left-pains-leg",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.parts.category"));
        //Cape
        class_304 skin_key_cape = KeyBindingHelper.registerKeyBinding(new class_304(
                "option.skin-key-cape",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN,
                "option.skin-layers-hide.parts.category"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Grups

            // On/off all layers
            while (skin_key_all_no_cape.method_1436()) {
                class_310.method_1551().field_1690.method_1631(class_1664.field_7564, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7568, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7570, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7566, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7565, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7563, SkinLayersHideAll[0]);
                SkinLayersHideAll[0] = !SkinLayersHideAll[0];
            }
            //all
            while (skin_key_all.method_1436()) {
                class_310.method_1551().field_1690.method_1631(class_1664.field_7559, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7564, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7568, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7570, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7566, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7565, SkinLayersHideAll[0]);
                class_310.method_1551().field_1690.method_1631(class_1664.field_7563, SkinLayersHideAll[0]);
                SkinLayersHideAll[0] = !SkinLayersHideAll[0];
            }

            while (skin_key_hat.method_1436()) {
                class_310.method_1551().field_1690.method_1631(class_1664.field_7563, !class_310.method_1551().field_1690.method_32594(class_1664.field_7563));
                if (skin_key_hat.method_1435(skin_key_jacket)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7564,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7564)
                    );
                }
                if (skin_key_hat.method_1435(skin_key_right_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7570,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7570)
                    );
                }
                if (skin_key_hat.method_1435(skin_key_left_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7568,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7568)
                    );
                }
                if (skin_key_hat.method_1435(skin_key_right_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7565,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7565)
                    );
                }
                if (skin_key_hat.method_1435(skin_key_left_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7566,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7566)
                    );
                }
                if (skin_key_hat.method_1435(skin_key_cape)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7559,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7559)
                    );
                }
            }
            while (skin_key_jacket.method_1436()) {
                if (skin_key_jacket.method_1435(skin_key_hat)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7563,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7563)
                    );
                }
                class_310.method_1551().field_1690.method_1631(
                        class_1664.field_7564,
                        !class_310.method_1551().field_1690.method_32594(class_1664.field_7564)
                );
                if (skin_key_jacket.method_1435(skin_key_right_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7570,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7570)
                    );
                }
                if (skin_key_jacket.method_1435(skin_key_left_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7568,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7568)
                    );
                }
                if (skin_key_jacket.method_1435(skin_key_right_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7565,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7565)
                    );
                }
                if (skin_key_jacket.method_1435(skin_key_left_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7566,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7566)
                    );
                }
                if (skin_key_jacket.method_1435(skin_key_cape)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7559,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7559)
                    );
                }
            }
            // On/off Right hand
            while (skin_key_right_sleeve.method_1436()) {
                if (skin_key_right_sleeve.method_1435(skin_key_hat)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7563,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7563)
                    );
                }
                if (skin_key_right_sleeve.method_1435(skin_key_jacket)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7564,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7564)
                    );
                }
                class_310.method_1551().field_1690.method_1631(class_1664.field_7570, !class_310.method_1551().field_1690.method_32594(class_1664.field_7570));
                if (skin_key_right_sleeve.method_1435(skin_key_left_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7568,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7568)
                    );
                }
                if (skin_key_right_sleeve.method_1435(skin_key_right_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7565,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7565)
                    );
                }
                if (skin_key_right_sleeve.method_1435(skin_key_left_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7566,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7566)
                    );
                }
                if (skin_key_right_sleeve.method_1435(skin_key_cape)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7559,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7559)
                    );
                }
            }
            // On/off left hand
            while (skin_key_left_sleeve.method_1436()) {
                if (skin_key_left_sleeve.method_1435(skin_key_hat)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7563,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7563)
                    );
                }
                if (skin_key_left_sleeve.method_1435(skin_key_jacket)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7564,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7564)
                    );
                }
                if (skin_key_left_sleeve.method_1435(skin_key_right_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7570,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7570)
                    );
                }
                class_310.method_1551().field_1690.method_1631(
                        class_1664.field_7568,
                        !class_310.method_1551().field_1690.method_32594(class_1664.field_7568)
                );
                if (skin_key_left_sleeve.method_1435(skin_key_right_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7565,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7565)
                    );
                }
                if (skin_key_left_sleeve.method_1435(skin_key_left_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7566,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7566)
                    );
                }
                if (skin_key_left_sleeve.method_1435(skin_key_cape)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7559,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7559)
                    );
                }
            }
            // On/off Right leg
            while (skin_key_right_pains_leg.method_1436()) {
                if (skin_key_right_pains_leg.method_1435(skin_key_hat)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7563,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7563)
                    );
                }
                if (skin_key_right_pains_leg.method_1435(skin_key_jacket)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7564,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7564)
                    );
                }
                if (skin_key_right_pains_leg.method_1435(skin_key_right_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7570,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7570)
                    );
                }
                if (skin_key_right_pains_leg.method_1435(skin_key_left_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7568,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7568)
                    );
                }
                class_310.method_1551().field_1690.method_1631(
                        class_1664.field_7565,
                        !class_310.method_1551().field_1690.method_32594(class_1664.field_7565)
                );
                if (skin_key_right_pains_leg.method_1435(skin_key_left_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7566,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7566)
                    );
                }
                if (skin_key_right_pains_leg.method_1435(skin_key_cape)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7559,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7559)
                    );
                }
            }
            // On/off left leg
            while (skin_key_left_pains_leg.method_1436()) {
                if (skin_key_left_pains_leg.method_1435(skin_key_hat)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7563,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7563)
                    );
                }
                if (skin_key_left_pains_leg.method_1435(skin_key_jacket)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7564,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7564)
                    );
                }
                if (skin_key_left_pains_leg.method_1435(skin_key_right_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7570,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7570)
                    );
                }
                if (skin_key_left_pains_leg.method_1435(skin_key_left_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7568,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7568)
                    );
                }
                if (skin_key_left_pains_leg.method_1435(skin_key_right_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7565,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7565)
                    );
                }
                class_310.method_1551().field_1690.method_1631(
                        class_1664.field_7566,
                        !class_310.method_1551().field_1690.method_32594(class_1664.field_7566)
                );
                if (skin_key_left_pains_leg.method_1435(skin_key_cape)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7559,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7559)
                    );
                }
            }
            // On/off cape
            while (skin_key_cape.method_1436()) {
                if (skin_key_cape.method_1435(skin_key_hat)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7563,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7563)
                    );
                }
                if (skin_key_cape.method_1435(skin_key_jacket)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7564,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7564)
                    );

                }
                if (skin_key_cape.method_1435(skin_key_right_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7570,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7570)
                    );
                }
                if (skin_key_cape.method_1435(skin_key_left_sleeve)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7568,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7568)
                    );
                }
                if (skin_key_cape.method_1435(skin_key_right_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7565,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7565)
                    );
                }
                if (skin_key_cape.method_1435(skin_key_left_pains_leg)) {
                    class_310.method_1551().field_1690.method_1631(
                            class_1664.field_7566,
                            !class_310.method_1551().field_1690.method_32594(class_1664.field_7566)
                    );
                }
                class_310.method_1551().field_1690.method_1631(
                        class_1664.field_7559,
                        !class_310.method_1551().field_1690.method_32594(class_1664.field_7559)
                );
            }
        });
    }
}
